package com.ckauto.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    lateinit var web: WebView

    companion object {
        var ref: MainActivity? = null
        fun deliver() {
            val w = ref?.web ?: return
            w.post { w.evaluateJavascript("window.drainSms&&drainSms()", null) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ref = this
        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        UssdEngine.onDone = { id, ok, text ->
            runOnUiThread {
                web.evaluateJavascript(
                    "window.onUssdDone(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(text) + ")", null
                )
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("nativeBack()") { r -> if (r != "true") moveTaskToBack(true) }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.drainSms&&drainSms();window.refreshSetup&&refreshSetup()", null)
    }

    override fun onDestroy() {
        if (ref === this) ref = null
        super.onDestroy()
    }
}
