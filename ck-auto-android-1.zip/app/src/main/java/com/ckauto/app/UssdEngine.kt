package com.ckauto.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray

data class Step(val t: String, val v: String = "", val more: Boolean = false, val p: Int = 0)

sealed class Action {
    data class Reply(val s: String) : Action()
    object Dismiss : Action()
    object Leave : Action()
    object None : Action()
}

/** Runs one USSD session: the web app sends a list of steps, this answers each screen. */
object UssdEngine {
    private val main = Handler(Looper.getMainLooper())
    var active = false
        private set
    private var id = ""
    private var steps: List<Step> = emptyList()
    private var idx = 0
    private var moreTries = 0
    private val timeout = Runnable { finish(false, "Timed out waiting for the USSD reply") }
    var onDone: ((String, Boolean, String) -> Unit)? = null
    var onAsk: ((String, String) -> Unit)? = null
    private var asking = false
    private var pending: Action? = null
    private var extra = 0

    /** The user answered the in-app confirmation (for example the recipient name). */
    fun answer(yes: Boolean) {
        if (!asking) return
        asking = false
        if (yes) {
            val s = steps[idx]
            idx++
            pending = Action.Reply(s.v.ifEmpty { "1" })
            arm()
        } else {
            pending = Action.Dismiss
            finish(false, "Cancelled by you")
        }
        UssdService.kick()
    }

    fun start(sid: String, json: String) {
        val a = JSONArray(json)
        steps = (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Step(o.getString("t"), o.optString("v"), o.optBoolean("more", false), o.optInt("p", 0))
        }
        idx = 0
        moreTries = 0
        extra = 0
        asking = false
        pending = null
        id = sid
        active = true
        arm()
    }

    fun fail(sid: String, why: String) {
        onDone?.invoke(sid, false, why)
    }

    private fun arm() {
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, 30000)
    }

    private fun finish(ok: Boolean, text: String) {
        if (!active) return
        active = false
        main.removeCallbacks(timeout)
        onDone?.invoke(id, ok, text)
    }

    private val optRe = Regex("^\\s*(\\d+)\\s*[:.)\\-]\\s*(.*)$")
    private val atRe = Regex("at\\s*(\\d+)", RegexOption.IGNORE_CASE)

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s"), "")

    private fun options(text: String): List<Pair<String, String>> =
        text.lines().mapNotNull { l -> optRe.find(l)?.let { it.groupValues[1] to it.groupValues[2] } }

    private fun findOpt(text: String, key: String): String? {
        val k = norm(key)
        return options(text).firstOrNull { norm(it.second).contains(k) }?.first
    }

    private fun findPrice(text: String, p: Int): String? =
        options(text).firstOrNull { atRe.find(it.second)?.groupValues?.get(1)?.toIntOrNull() == p }?.first

    /** Called by the accessibility service with the current USSD screen. */
    fun next(text: String, hasInput: Boolean): Action {
        pending?.let {
            pending = null
            return it
        }
        if (!active) return Action.None
        if (!asking) arm()
        if (!hasInput) {
            val ok = idx >= steps.size
            finish(ok, if (ok) text else "Ended early: $text")
            return Action.Dismiss
        }
        if (idx >= steps.size) {
            val c = findOpt(text, "accept") ?: findOpt(text, "confirm") ?: findOpt(text, "yes")
            if (c != null && extra < 2) {
                extra++
                return Action.Reply(c)
            }
            finish(false, "Unexpected extra prompt: $text")
            return Action.Dismiss
        }
        val s = steps[idx]
        return when (s.t) {
            "text" -> {
                idx++
                Action.Reply(s.v)
            }
            "ask" -> {
                if (!asking) {
                    asking = true
                    main.removeCallbacks(timeout)
                    main.postDelayed(timeout, 120000)
                    onAsk?.invoke(id, text)
                }
                Action.Leave
            }
            "stop" -> {
                finish(true, text)
                Action.Leave
            }
            "find", "price" -> {
                val n = if (s.t == "find") findOpt(text, s.v) else findPrice(text, s.p)
                if (n != null) {
                    idx++
                    moreTries = 0
                    Action.Reply(n)
                } else {
                    val m = if (s.more) findOpt(text, "more") else null
                    if (m != null && moreTries < 4) {
                        moreTries++
                        Action.Reply(m)
                    } else {
                        finish(false, "Option not found on the menu: " + s.v.ifEmpty { s.p.toString() })
                        Action.Dismiss
                    }
                }
            }
            else -> {
                finish(false, "Unknown step")
                Action.Dismiss
            }
        }
    }
}
